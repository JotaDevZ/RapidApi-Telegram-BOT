import requests
import hashlib
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# ==============================
# CONFIGURACIÓN
# ==============================
TELEGRAM_TOKEN = "pon tu token de bot de telegram aqui colega"
RAPIDAPI_KEY = "usa una api de rapidapi"
RAPIDAPI_HOST = "breachdirectory.p.rapidapi.com"  # Esto ni lo toques

# ==============================
# FUNCIÓN PARA CONSULTAR LA API
# ==============================
def query_breachdirectory(query):
    url = f"https://{RAPIDAPI_HOST}/?func=auto&term={query}"
    headers = {
        "X-RapidAPI-Key": RAPIDAPI_KEY,
        "X-RapidAPI-Host": RAPIDAPI_HOST
    }
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        return {"error": f"Error {response.status_code}: {response.text}"}

# ==============================
# FUNCIÓN PARA INTENTAR CRACKEAR HASHES
# ==============================
def crack_hash(hash_value, wordlist="rockyou.txt"):
    algorithms = {
        32: "md5",
        40: "sha1",
        64: "sha256"
    }

    algo = algorithms.get(len(hash_value))
    if not algo:
        return "❌ Algoritmo no soportado (solo MD5/SHA1/SHA256)."

    if not os.path.exists(wordlist):
        return f"⚠️ No se encontró el diccionario {wordlist}."

    with open(wordlist, "r", encoding="latin-1", errors="ignore") as f:
        for password in f:
            password = password.strip()
            h = hashlib.new(algo)
            h.update(password.encode("utf-8"))
            if h.hexdigest() == hash_value.lower():
                return f"✅ Hash crackeado: {password}"

    return "❌ No se encontró la contraseña en el diccionario."

# ==============================
# HANDLERS DEL BOT
# ==============================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Hola! Envíame un email o usuario y buscaré en la nueva API de RapidAPI.")

async def handle_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.message.text.strip()
    data = query_breachdirectory(query)

    if "error" in data:
        await update.message.reply_text(data["error"])
        return

    if not data.get("result"):
        await update.message.reply_text("✅ No se encontraron resultados.")
        return

    for entry in data["result"]:
        email = entry.get("email", "N/A")
        hash_value = entry.get("hash", "N/A")
        password = entry.get("password", "❌ No disponible")
        sources = ", ".join(entry.get("sources", [])) if entry.get("sources") else "Desconocido"

        text = (
            f"📧 Email/Usuario: {email}\n"
            f"🔑 Hash: {hash_value}\n"
            f"🔓 Contraseña: {password}\n"
            f"📂 Fuentes: {sources}"
        )

        # Botón para crackear el hash
        keyboard = [[InlineKeyboardButton("🔓 Intentar crackear", callback_data=f"crack:{hash_value}")]]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(text, reply_markup=reply_markup)

# ==============================
# CALLBACK PARA BOTONES
# ==============================
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data.startswith("crack:"):
        hash_value = query.data.split(":", 1)[1]
        result = crack_hash(hash_value)
        await query.edit_message_text(f"🔑 Hash: {hash_value}\n\n{result}")

# ==============================
# MAIN
# ==============================
def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_query))
    app.add_handler(CallbackQueryHandler(button_callback))

    print("🤖 Bot iniciado...")
    app.run_polling()

if __name__ == "__main__":
    main()
